import React,{useState} from 'react'
import axios from 'axios'
import './App.css';

function App() {
  const [name,setName] =useState('')
  const [mail,setMail] =useState('')
  const [msg,setMsg] =useState('')

  const submit = (e) => {
e.preventDefault();
    let data = {
      name:name,
      mail:mail,
      message:""
    }
    let str = JSON.stringify(data)
    axios.post('http://localhost:8081/send',data).then(
      res => {
        console.log(res,"response")
        setMsg(res.data)
      }
    )
    .catch(
      err => {
        console.log(err,"err")
      }
    )
    console.log(data)
    console.log(str)
    console.log(JSON.parse(str),"parse")
    setName('');
    setMail('');
  }
  return (
    <div className="App">
       <form>
         <div>
           <label>UserNAme</label>
           <input type="text" placeholder="username" value={name} onChange={(e) => setName(e.target.value)} />
         </div>
         <br/>
         <div>
           <label>Mail</label>
           <input type="text" placeholder="Mail" value={mail}  onChange={(e) => setMail(e.target.value)} />
         </div>
         <br/>
         <div>
           <button onClick={submit}>Submit</button>
         </div>
         <br/>
         
         <div>
          
         </div>
       </form>
    </div>
  );
}

export default App;
