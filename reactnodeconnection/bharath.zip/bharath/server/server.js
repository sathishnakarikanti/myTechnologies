const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose')
var cookieParser = require('cookie-parser')
const app = express();
app.use(cors());
app.use(express.json());
app.use(cookieParser())

mongoose.connect("mongodb+srv://bharath:9490563662@cluster0.al0q1.mongodb.net/food?retryWrites=true&w=majority",
{
    useNewUrlParser: true,
    // useFindAndModify: false,
    // useUnifiedTopology: true
  })


app.post('/send',(req,res)=>{
    // console.log(req)
    if(req.body.name == "bharath"){
        let one = {
            name:"test",
            pas:"#test"
        }
        res.send(req.body.message = one)
        // console.log("Cookies: ", req)
        
    }
    else {
        res.send(req.body.message = "wrong")
    }
    res.send(req.body.ame)
})
app.get('/getdata', function(req, res, next) {
      
    console.log(req.cookies,"req.cookies")
 
});

const PORT = process.env.PORT || 8081;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});




// var express = require('express')
// var cookieParser = require('cookie-parser')
 
// var app = express()
// app.use(cookieParser())
 
// app.get('/', function (req, res) {
//   // Cookies that have not been signed
//   console.log('Cookies: ', req.cookies)
 
//   // Cookies that have been signed
//   console.log('Signed Cookies: ', req.signedCookies)
// })
 
// app.listen(8081)